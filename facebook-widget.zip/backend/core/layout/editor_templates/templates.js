[
	{
		"title": "Left aligned image",
		"image": "/backend/core/layout/editor_templates/images/left_aligned_image.gif",
		"description": "A paragraph of text with an image on the left.",
		"html": "<p><img class=alignLeft src=/backend/core/layout/editor_templates/images/left_aligned_image.gif height=70 width=100 />Type the text here</p>"
	},
	{
		"title": "Right aligned image",
		"image": "/backend/core/layout/editor_templates/images/right_aligned_image.gif",
		"description": "A paragraph of text with an image on the right.",
		"html": "<p><img class=alignLeft src=/backend/core/layout/editor_templates/images/right_aligned_image.gif height=70 width=100 />Type the text here</p>"
	}
]