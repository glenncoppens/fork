<?php

// custom constant used by the init classes
define('INIT_PATH_LIBRARY', 'C:\wamp\www\figure8\library');
