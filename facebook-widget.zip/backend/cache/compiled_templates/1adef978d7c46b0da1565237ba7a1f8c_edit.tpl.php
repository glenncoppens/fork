<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\locale\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\locale\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\locale\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\locale\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_start_module.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\locale\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\locale\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\locale\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\locale\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_start_module.tpl}<?php
				}
?>

<?php
					if(isset($this->forms['edit']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['edit']->getAction(); ?>" method="<?php echo $this->forms['edit']->getMethod(); ?>"<?php echo $this->forms['edit']->getParametersHTML(); ?>>
						<?php echo $this->forms['edit']->getField('form')->parse();
						if($this->forms['edit']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['edit']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['edit']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
	<div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblTranslations', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTranslations']); } else { ?>{$lblTranslations|ucfirst}<?php } ?>: <?php if(array_key_exists('msgEditTranslation', (array) $this->variables) && array_key_exists('name', (array) $this->variables)) { echo sprintf($this->variables['msgEditTranslation'], $this->variables['name']); } else { ?>{$msgEditTranslation|sprintf:<?php if(array_key_exists('name', (array) $this->variables)) { echo $this->variables['name']; } else { ?>{$name}<?php } ?>}<?php } ?></h3>
		</div>
		<div class="options">
			<div class="horizontal">
				<p>
					<label for="name"><?php if(array_key_exists('lblReferenceCode', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblReferenceCode']); } else { ?>{$lblReferenceCode|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
					<?php if(array_key_exists('txtName', (array) $this->variables)) { echo $this->variables['txtName']; } else { ?>{$txtName}<?php } ?> <?php if(array_key_exists('txtNameError', (array) $this->variables)) { echo $this->variables['txtNameError']; } else { ?>{$txtNameError}<?php } ?>
					<span class="helpTxt"><?php if(array_key_exists('msgHelpEditName', (array) $this->variables)) { echo $this->variables['msgHelpEditName']; } else { ?>{$msgHelpEditName}<?php } ?></span>
				</p>
				<p>
					<label for="value"><?php if(array_key_exists('lblTranslation', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTranslation']); } else { ?>{$lblTranslation|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo $this->variables['lblRequiredField']; } else { ?>{$lblRequiredField}<?php } ?>">*</abbr></label>
					<?php if(array_key_exists('txtValue', (array) $this->variables)) { echo $this->variables['txtValue']; } else { ?>{$txtValue}<?php } ?> <?php if(array_key_exists('txtValueError', (array) $this->variables)) { echo $this->variables['txtValueError']; } else { ?>{$txtValueError}<?php } ?>
					<span class="helpTxt"><?php if(array_key_exists('msgHelpEditValue', (array) $this->variables)) { echo $this->variables['msgHelpEditValue']; } else { ?>{$msgHelpEditValue}<?php } ?></span>
				</p>
				<p>
					<label for="language"><?php if(array_key_exists('lblLanguage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblLanguage']); } else { ?>{$lblLanguage|ucfirst}<?php } ?></label>
					<?php if(array_key_exists('ddmLanguage', (array) $this->variables)) { echo $this->variables['ddmLanguage']; } else { ?>{$ddmLanguage}<?php } ?> <?php if(array_key_exists('ddmLanguageError', (array) $this->variables)) { echo $this->variables['ddmLanguageError']; } else { ?>{$ddmLanguageError}<?php } ?>
				</p>
				<p>
					<label for="application"><?php if(array_key_exists('lblApplication', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblApplication']); } else { ?>{$lblApplication|ucfirst}<?php } ?></label>
					<?php if(array_key_exists('ddmApplication', (array) $this->variables)) { echo $this->variables['ddmApplication']; } else { ?>{$ddmApplication}<?php } ?> <?php if(array_key_exists('ddmApplicationError', (array) $this->variables)) { echo $this->variables['ddmApplicationError']; } else { ?>{$ddmApplicationError}<?php } ?>
				</p>
				<p>
					<label for="module"><?php if(array_key_exists('lblModule', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblModule']); } else { ?>{$lblModule|ucfirst}<?php } ?></label>
					<?php if(array_key_exists('ddmModule', (array) $this->variables)) { echo $this->variables['ddmModule']; } else { ?>{$ddmModule}<?php } ?> <?php if(array_key_exists('ddmModuleError', (array) $this->variables)) { echo $this->variables['ddmModuleError']; } else { ?>{$ddmModuleError}<?php } ?>
				</p>
				<p>
					<label for="type"><?php if(array_key_exists('lblType', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblType']); } else { ?>{$lblType|ucfirst}<?php } ?></label>
					<?php if(array_key_exists('ddmType', (array) $this->variables)) { echo $this->variables['ddmType']; } else { ?>{$ddmType}<?php } ?> <?php if(array_key_exists('ddmTypeError', (array) $this->variables)) { echo $this->variables['ddmTypeError']; } else { ?>{$ddmTypeError}<?php } ?>
				</p>
			</div>
		</div>

		<div class="fullwidthOptions">
			<?php
					if(isset($this->variables['showLocaleDelete']) && count($this->variables['showLocaleDelete']) != 0 && $this->variables['showLocaleDelete'] != '' && $this->variables['showLocaleDelete'] !== false)
					{
						?>
			<a href="<?php if(array_key_exists('var', (array) $this->variables)) { echo BackendTemplateModifiers::getURL($this->variables['var'], 'delete'); } else { ?>{$var|geturl:'delete'}<?php } ?>&amp;id=<?php if(array_key_exists('id', (array) $this->variables)) { echo $this->variables['id']; } else { ?>{$id}<?php } ?><?php if(array_key_exists('filterQuery', (array) $this->variables)) { echo $this->variables['filterQuery']; } else { ?>{$filterQuery}<?php } ?>" data-message-id="confirmDelete" class="askConfirmation button linkButton icon iconDelete">
				<span><?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?></span>
			</a>
			<div id="confirmDelete" title="<?php if(array_key_exists('lblDelete', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDelete']); } else { ?>{$lblDelete|ucfirst}<?php } ?>?" style="display: none;">
				<p>
					<?php if(array_key_exists('msgConfirmDelete', (array) $this->variables)) { echo $this->variables['msgConfirmDelete']; } else { ?>{$msgConfirmDelete}<?php } ?>
				</p>
			</div>
			<?php } ?>

			<div class="buttonHolderRight">
				<input id="editButton" class="inputButton button mainButton" type="submit" name="edit" value="<?php if(array_key_exists('lblSave', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSave']); } else { ?>{$lblSave|ucfirst}<?php } ?>" />
			</div>
		</div>
	</div>
</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_end_module.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\locale\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\locale\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\locale\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\locale\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_end_module.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\locale\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\locale\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\locale\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\locale\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/footer.tpl}<?php
				}
?>
