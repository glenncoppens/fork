<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\faq\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\faq\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\faq\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\faq\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_start_module.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\faq\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\faq\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\faq\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\faq\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_start_module.tpl}<?php
				}
?>

<div class="pageTitle">
	<h2><?php if(array_key_exists('lblModuleSettings', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblModuleSettings']); } else { ?>{$lblModuleSettings|ucfirst}<?php } ?>: <?php if(array_key_exists('lblFaq', (array) $this->variables)) { echo $this->variables['lblFaq']; } else { ?>{$lblFaq}<?php } ?></h2>
</div>

<?php
					if(isset($this->forms['settings']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['settings']->getAction(); ?>" method="<?php echo $this->forms['settings']->getMethod(); ?>"<?php echo $this->forms['settings']->getParametersHTML(); ?>>
						<?php echo $this->forms['settings']->getField('form')->parse();
						if($this->forms['settings']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['settings']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['settings']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
	<div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblPagination', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPagination']); } else { ?>{$lblPagination|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<label for="overviewNumberOfItemsPerCategory"><?php if(array_key_exists('lblItemsPerCategory', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblItemsPerCategory']); } else { ?>{$lblItemsPerCategory|ucfirst}<?php } ?></label>
			<?php if(array_key_exists('ddmOverviewNumberOfItemsPerCategory', (array) $this->variables)) { echo $this->variables['ddmOverviewNumberOfItemsPerCategory']; } else { ?>{$ddmOverviewNumberOfItemsPerCategory}<?php } ?> <?php if(array_key_exists('ddmOverviewNumberOfItemsPerCategoryError', (array) $this->variables)) { echo $this->variables['ddmOverviewNumberOfItemsPerCategoryError']; } else { ?>{$ddmOverviewNumberOfItemsPerCategoryError}<?php } ?>
		</div>
		<div class="options">
			<label for="mostReadNumberOfItems"><?php if(array_key_exists('msgNumMostReadItems', (array) $this->variables)) { echo $this->variables['msgNumMostReadItems']; } else { ?>{$msgNumMostReadItems}<?php } ?></label>
			<?php if(array_key_exists('ddmMostReadNumberOfItems', (array) $this->variables)) { echo $this->variables['ddmMostReadNumberOfItems']; } else { ?>{$ddmMostReadNumberOfItems}<?php } ?> <?php if(array_key_exists('ddmMostReadNumberOfItemsError', (array) $this->variables)) { echo $this->variables['ddmMostReadNumberOfItemsError']; } else { ?>{$ddmMostReadNumberOfItemsError}<?php } ?>
		</div>
		<div class="options">
			<label for="relatedNumberOfItems"><?php if(array_key_exists('msgNumRelatedItems', (array) $this->variables)) { echo $this->variables['msgNumRelatedItems']; } else { ?>{$msgNumRelatedItems}<?php } ?></label>
			<?php if(array_key_exists('ddmRelatedNumberOfItems', (array) $this->variables)) { echo $this->variables['ddmRelatedNumberOfItems']; } else { ?>{$ddmRelatedNumberOfItems}<?php } ?> <?php if(array_key_exists('ddmRelatedNumberOfItemsError', (array) $this->variables)) { echo $this->variables['ddmRelatedNumberOfItemsError']; } else { ?>{$ddmRelatedNumberOfItemsError}<?php } ?>
		</div>
	</div>
    
    <div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblCategories', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblCategories']); } else { ?>{$lblCategories|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<label for="allowMultipleCategories"><?php if(array_key_exists('chkAllowMultipleCategories', (array) $this->variables)) { echo $this->variables['chkAllowMultipleCategories']; } else { ?>{$chkAllowMultipleCategories}<?php } ?> <?php if(array_key_exists('lblAllowMultipleCategories', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAllowMultipleCategories']); } else { ?>{$lblAllowMultipleCategories|ucfirst}<?php } ?></label>
		</div>
    </div>

	<div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblFeedback', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFeedback']); } else { ?>{$lblFeedback|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<ul class="inputList">
				<li><label for="allowFeedback"><?php if(array_key_exists('chkAllowFeedback', (array) $this->variables)) { echo $this->variables['chkAllowFeedback']; } else { ?>{$chkAllowFeedback}<?php } ?> <?php if(array_key_exists('lblAllowFeedback', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAllowFeedback']); } else { ?>{$lblAllowFeedback|ucfirst}<?php } ?></label></li>
				<li><label for="allowOwnQuestion"><?php if(array_key_exists('chkAllowOwnQuestion', (array) $this->variables)) { echo $this->variables['chkAllowOwnQuestion']; } else { ?>{$chkAllowOwnQuestion}<?php } ?> <?php if(array_key_exists('lblAllowOwnQuestion', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAllowOwnQuestion']); } else { ?>{$lblAllowOwnQuestion|ucfirst}<?php } ?></label></li>
				<li><label for="sendEmailOnNewFeedback"><?php if(array_key_exists('chkSendEmailOnNewFeedback', (array) $this->variables)) { echo $this->variables['chkSendEmailOnNewFeedback']; } else { ?>{$chkSendEmailOnNewFeedback}<?php } ?> <?php if(array_key_exists('lblSendEmailOnNewFeedback', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSendEmailOnNewFeedback']); } else { ?>{$lblSendEmailOnNewFeedback|ucfirst}<?php } ?></label>
				<li>
					<label for="spamfilter"><?php if(array_key_exists('chkSpamfilter', (array) $this->variables)) { echo $this->variables['chkSpamfilter']; } else { ?>{$chkSpamfilter}<?php } ?> <?php if(array_key_exists('lblFilterCommentsForSpam', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFilterCommentsForSpam']); } else { ?>{$lblFilterCommentsForSpam|ucfirst}<?php } ?></label>
					<span class="helpTxt">
						<?php if(array_key_exists('msgHelpSpamFilter', (array) $this->variables)) { echo $this->variables['msgHelpSpamFilter']; } else { ?>{$msgHelpSpamFilter}<?php } ?>
						<?php
					if(isset($this->variables['noAkismetKey']) && count($this->variables['noAkismetKey']) != 0 && $this->variables['noAkismetKey'] != '' && $this->variables['noAkismetKey'] !== false)
					{
						?><span class="infoMessage"><br /><?php if(array_key_exists('msgNoAkismetKey', (array) $this->variables) && array_key_exists('var', (array) $this->variables)) { echo sprintf($this->variables['msgNoAkismetKey'], BackendTemplateModifiers::getURL($this->variables['var'], 'index', 'settings')); } else { ?>{$msgNoAkismetKey|sprintf:<?php if(array_key_exists('var', (array) $this->variables)) { echo BackendTemplateModifiers::getURL($this->variables['var'], 'index', 'settings'); } else { ?>{$var|geturl:'index':'settings'}<?php } ?>}<?php } ?></span><?php } ?>
					</span>
				</li>
			</ul>
		</div>
	</div>

	<div class="fullwidthOptions">
		<div class="buttonHolderRight">
			<input id="save" class="inputButton button mainButton" type="submit" name="save" value="<?php if(array_key_exists('lblSave', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSave']); } else { ?>{$lblSave|ucfirst}<?php } ?>" />
		</div>
	</div>
</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_end_module.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\faq\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\faq\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\faq\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\faq\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_end_module.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\faq\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\faq\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\faq\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\faq\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/footer.tpl}<?php
				}
?>