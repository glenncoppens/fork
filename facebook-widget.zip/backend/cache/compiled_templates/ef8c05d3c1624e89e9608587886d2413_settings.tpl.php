<?php error_reporting(E_ALL | E_STRICT); ini_set('display_errors', 'On'); ?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/head.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\blog\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\blog\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\blog\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\blog\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/head.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_start_module.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\blog\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\blog\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\blog\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\blog\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_start_module.tpl}<?php
				}
?>

<div class="pageTitle">
	<h2><?php if(array_key_exists('lblModuleSettings', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblModuleSettings']); } else { ?>{$lblModuleSettings|ucfirst}<?php } ?>: <?php if(array_key_exists('lblBlog', (array) $this->variables)) { echo $this->variables['lblBlog']; } else { ?>{$lblBlog}<?php } ?></h2>
</div>

<?php
					if(isset($this->forms['settings']))
					{
						?><form accept-charset="UTF-8" action="<?php echo $this->forms['settings']->getAction(); ?>" method="<?php echo $this->forms['settings']->getMethod(); ?>"<?php echo $this->forms['settings']->getParametersHTML(); ?>>
						<?php echo $this->forms['settings']->getField('form')->parse();
						if($this->forms['settings']->getUseToken())
						{
							?><input type="hidden" name="form_token" id="<?php echo $this->forms['settings']->getField('form_token')->getAttribute('id'); ?>" value="<?php echo htmlspecialchars($this->forms['settings']->getField('form_token')->getValue()); ?>" />
						<?php } ?>
	<div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblPagination', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPagination']); } else { ?>{$lblPagination|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<label for="overviewNumberOfItems"><?php if(array_key_exists('lblItemsPerPage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblItemsPerPage']); } else { ?>{$lblItemsPerPage|ucfirst}<?php } ?></label>
			<?php if(array_key_exists('ddmOverviewNumberOfItems', (array) $this->variables)) { echo $this->variables['ddmOverviewNumberOfItems']; } else { ?>{$ddmOverviewNumberOfItems}<?php } ?> <?php if(array_key_exists('ddmOverviewNumberOfItemsError', (array) $this->variables)) { echo $this->variables['ddmOverviewNumberOfItemsError']; } else { ?>{$ddmOverviewNumberOfItemsError}<?php } ?>
		</div>
		<div class="options">
			<label for="recentArticlesFullNumberOfItems"><?php if(array_key_exists('msgNumItemsInRecentArticlesFull', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['msgNumItemsInRecentArticlesFull']); } else { ?>{$msgNumItemsInRecentArticlesFull|ucfirst}<?php } ?></label>
			<?php if(array_key_exists('ddmRecentArticlesFullNumberOfItems', (array) $this->variables)) { echo $this->variables['ddmRecentArticlesFullNumberOfItems']; } else { ?>{$ddmRecentArticlesFullNumberOfItems}<?php } ?> <?php if(array_key_exists('ddmRecentArticlesFullNumberOfItemsError', (array) $this->variables)) { echo $this->variables['ddmRecentArticlesFullNumberOfItemsError']; } else { ?>{$ddmRecentArticlesFullNumberOfItemsError}<?php } ?>
		</div>
		<div class="options">
			<label for="recentArticlesListNumberOfItems"><?php if(array_key_exists('msgNumItemsInRecentArticlesList', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['msgNumItemsInRecentArticlesList']); } else { ?>{$msgNumItemsInRecentArticlesList|ucfirst}<?php } ?></label>
			<?php if(array_key_exists('ddmRecentArticlesListNumberOfItems', (array) $this->variables)) { echo $this->variables['ddmRecentArticlesListNumberOfItems']; } else { ?>{$ddmRecentArticlesListNumberOfItems}<?php } ?> <?php if(array_key_exists('ddmRecentArticlesListNumberOfItemsError', (array) $this->variables)) { echo $this->variables['ddmRecentArticlesListNumberOfItemsError']; } else { ?>{$ddmRecentArticlesListNumberOfItemsError}<?php } ?>
		</div>
	</div>

	<div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblComments', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblComments']); } else { ?>{$lblComments|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<ul class="inputList">
				<li><label for="allowComments"><?php if(array_key_exists('chkAllowComments', (array) $this->variables)) { echo $this->variables['chkAllowComments']; } else { ?>{$chkAllowComments}<?php } ?> <?php if(array_key_exists('lblAllowComments', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblAllowComments']); } else { ?>{$lblAllowComments|ucfirst}<?php } ?></label></li>
				<li><label for="moderation"><?php if(array_key_exists('chkModeration', (array) $this->variables)) { echo $this->variables['chkModeration']; } else { ?>{$chkModeration}<?php } ?> <?php if(array_key_exists('lblEnableModeration', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblEnableModeration']); } else { ?>{$lblEnableModeration|ucfirst}<?php } ?></label></li>
				<li>
					<label for="spamfilter"><?php if(array_key_exists('chkSpamfilter', (array) $this->variables)) { echo $this->variables['chkSpamfilter']; } else { ?>{$chkSpamfilter}<?php } ?> <?php if(array_key_exists('lblFilterCommentsForSpam', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFilterCommentsForSpam']); } else { ?>{$lblFilterCommentsForSpam|ucfirst}<?php } ?></label>
					<span class="helpTxt">
						<?php if(array_key_exists('msgHelpSpamFilter', (array) $this->variables)) { echo $this->variables['msgHelpSpamFilter']; } else { ?>{$msgHelpSpamFilter}<?php } ?>
						<?php
					if(isset($this->variables['noAkismetKey']) && count($this->variables['noAkismetKey']) != 0 && $this->variables['noAkismetKey'] != '' && $this->variables['noAkismetKey'] !== false)
					{
						?><span class="infoMessage"><br /><?php if(array_key_exists('msgNoAkismetKey', (array) $this->variables) && array_key_exists('var', (array) $this->variables)) { echo sprintf($this->variables['msgNoAkismetKey'], BackendTemplateModifiers::getURL($this->variables['var'], 'index', 'settings')); } else { ?>{$msgNoAkismetKey|sprintf:<?php if(array_key_exists('var', (array) $this->variables)) { echo BackendTemplateModifiers::getURL($this->variables['var'], 'index', 'settings'); } else { ?>{$var|geturl:'index':'settings'}<?php } ?>}<?php } ?></span><?php } ?>
					</span>
				</li>
			</ul>
			<p class="p0"><?php if(array_key_exists('msgFollowAllCommentsInRSS', (array) $this->variables) && array_key_exists('commentsRSSURL', (array) $this->variables)) { echo sprintf($this->variables['msgFollowAllCommentsInRSS'], $this->variables['commentsRSSURL']); } else { ?>{$msgFollowAllCommentsInRSS|sprintf:<?php if(array_key_exists('commentsRSSURL', (array) $this->variables)) { echo $this->variables['commentsRSSURL']; } else { ?>{$commentsRSSURL}<?php } ?>}<?php } ?></p>
		</div>
	</div>

	<?php
					if(isset($this->variables['isGod']) && count($this->variables['isGod']) != 0 && $this->variables['isGod'] != '' && $this->variables['isGod'] !== false)
					{
						?>
	<div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblImage', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblImage']); } else { ?>{$lblImage|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<label for="showImageForm"><?php if(array_key_exists('chkShowImageForm', (array) $this->variables)) { echo $this->variables['chkShowImageForm']; } else { ?>{$chkShowImageForm}<?php } ?> <?php if(array_key_exists('msgShowImageForm', (array) $this->variables)) { echo $this->variables['msgShowImageForm']; } else { ?>{$msgShowImageForm}<?php } ?></label>
		</div>
	</div>
	<?php } ?>

	<div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblNotifications', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblNotifications']); } else { ?>{$lblNotifications|ucfirst}<?php } ?></h3>
		</div>
		<div class="options">
			<ul class="inputList p0">
				<li><label for="notifyByEmailOnNewCommentToModerate"><?php if(array_key_exists('chkNotifyByEmailOnNewCommentToModerate', (array) $this->variables)) { echo $this->variables['chkNotifyByEmailOnNewCommentToModerate']; } else { ?>{$chkNotifyByEmailOnNewCommentToModerate}<?php } ?> <?php if(array_key_exists('msgNotifyByEmailOnNewCommentToModerate', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['msgNotifyByEmailOnNewCommentToModerate']); } else { ?>{$msgNotifyByEmailOnNewCommentToModerate|ucfirst}<?php } ?></label></li>
				<li><label for="notifyByEmailOnNewComment"><?php if(array_key_exists('chkNotifyByEmailOnNewComment', (array) $this->variables)) { echo $this->variables['chkNotifyByEmailOnNewComment']; } else { ?>{$chkNotifyByEmailOnNewComment}<?php } ?> <?php if(array_key_exists('msgNotifyByEmailOnNewComment', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['msgNotifyByEmailOnNewComment']); } else { ?>{$msgNotifyByEmailOnNewComment|ucfirst}<?php } ?></label></li>
			</ul>
		</div>
	</div>

	<div class="box">
		<div class="heading">
			<h3><?php if(array_key_exists('lblSEO', (array) $this->variables)) { echo $this->variables['lblSEO']; } else { ?>{$lblSEO}<?php } ?></h3>
		</div>
		<div class="options">
			<p><?php if(array_key_exists('msgHelpPingServices', (array) $this->variables)) { echo $this->variables['msgHelpPingServices']; } else { ?>{$msgHelpPingServices}<?php } ?>:</p>
			<ul class="inputList p0">
				<li><label for="pingServices"><?php if(array_key_exists('chkPingServices', (array) $this->variables)) { echo $this->variables['chkPingServices']; } else { ?>{$chkPingServices}<?php } ?> <?php if(array_key_exists('lblPingBlogServices', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblPingBlogServices']); } else { ?>{$lblPingBlogServices|ucfirst}<?php } ?></label></li>
			</ul>
		</div>
	</div>

	<div class="box">
		<div class="horizontal">
			<div class="heading">
				<h3><?php if(array_key_exists('lblRSSFeed', (array) $this->variables)) { echo $this->variables['lblRSSFeed']; } else { ?>{$lblRSSFeed}<?php } ?></h3>
			</div>
			<div class="options">
				<label for="rssTitle"><?php if(array_key_exists('lblTitle', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblTitle']); } else { ?>{$lblTitle|ucfirst}<?php } ?><abbr title="<?php if(array_key_exists('lblRequiredField', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblRequiredField']); } else { ?>{$lblRequiredField|ucfirst}<?php } ?>">*</abbr></label>
				<?php if(array_key_exists('txtRssTitle', (array) $this->variables)) { echo $this->variables['txtRssTitle']; } else { ?>{$txtRssTitle}<?php } ?> <?php if(array_key_exists('txtRssTitleError', (array) $this->variables)) { echo $this->variables['txtRssTitleError']; } else { ?>{$txtRssTitleError}<?php } ?>
				<span class="helpTxt"><?php if(array_key_exists('msgHelpRSSTitle', (array) $this->variables)) { echo $this->variables['msgHelpRSSTitle']; } else { ?>{$msgHelpRSSTitle}<?php } ?></span>
			</div>
			<div class="options">
				<label for="rssDescription"><?php if(array_key_exists('lblDescription', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblDescription']); } else { ?>{$lblDescription|ucfirst}<?php } ?></label>
				<?php if(array_key_exists('txtRssDescription', (array) $this->variables)) { echo $this->variables['txtRssDescription']; } else { ?>{$txtRssDescription}<?php } ?> <?php if(array_key_exists('txtRssDescriptionError', (array) $this->variables)) { echo $this->variables['txtRssDescriptionError']; } else { ?>{$txtRssDescriptionError}<?php } ?>
				<span class="helpTxt"><?php if(array_key_exists('msgHelpRSSDescription', (array) $this->variables)) { echo $this->variables['msgHelpRSSDescription']; } else { ?>{$msgHelpRSSDescription}<?php } ?></span>
			</div>
			<div class="options">
				<label for="feedburnerUrl"><?php if(array_key_exists('lblFeedburnerURL', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblFeedburnerURL']); } else { ?>{$lblFeedburnerURL|ucfirst}<?php } ?></label>
				<?php if(array_key_exists('txtFeedburnerUrl', (array) $this->variables)) { echo $this->variables['txtFeedburnerUrl']; } else { ?>{$txtFeedburnerUrl}<?php } ?> <?php if(array_key_exists('txtFeedburnerUrlError', (array) $this->variables)) { echo $this->variables['txtFeedburnerUrlError']; } else { ?>{$txtFeedburnerUrlError}<?php } ?>
				<span class="helpTxt"><?php if(array_key_exists('msgHelpFeedburnerURL', (array) $this->variables)) { echo $this->variables['msgHelpFeedburnerURL']; } else { ?>{$msgHelpFeedburnerURL}<?php } ?></span>
			</div>
			<div class="options">
				<p><?php if(array_key_exists('msgHelpMeta', (array) $this->variables)) { echo $this->variables['msgHelpMeta']; } else { ?>{$msgHelpMeta}<?php } ?>:</p>
				<ul class="inputList p0">
					<li><label for="rssMeta"><?php if(array_key_exists('chkRssMeta', (array) $this->variables)) { echo $this->variables['chkRssMeta']; } else { ?>{$chkRssMeta}<?php } ?> <?php if(array_key_exists('lblMetaInformation', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblMetaInformation']); } else { ?>{$lblMetaInformation|ucfirst}<?php } ?></label></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="fullwidthOptions">
		<div class="buttonHolderRight">
			<input id="save" class="inputButton button mainButton" type="submit" name="save" value="<?php if(array_key_exists('lblSave', (array) $this->variables)) { echo SpoonFilter::ucfirst($this->variables['lblSave']); } else { ?>{$lblSave|ucfirst}<?php } ?>" />
		</div>
	</div>
</form>
				<?php } ?>

<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_end_module.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\blog\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\blog\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\blog\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\blog\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/structure_end_module.tpl}<?php
				}
?>
<?php
				ob_start();
				?><?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/footer.tpl<?php
				$include = eval('return \'' . str_replace('\'', '\\\'', ob_get_clean()) .'\';');
				if($this->getForceCompile()) $this->compile('C:\wamp\www\figure8\backend\modules\blog\layout\templates', $include);
				$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\blog\layout\templates');
				if($return === false && $this->compile('C:\wamp\www\figure8\backend\modules\blog\layout\templates', $include))
				{
					$return = @include $this->getCompileDirectory() .'/' . $this->getCompileName($include, 'C:\wamp\www\figure8\backend\modules\blog\layout\templates');
				}
if($return === false)
				{
					?>{include:<?php if(array_key_exists('BACKEND_CORE_PATH', (array) $this->variables)) { echo $this->variables['BACKEND_CORE_PATH']; } else { ?>{$BACKEND_CORE_PATH}<?php } ?>/layout/templates/footer.tpl}<?php
				}
?>